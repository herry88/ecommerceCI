<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	$config['charset'] = 'iso-8859-1';
	$config['protocol'] = 'mail';  
	$config['mailtype'] = 'html';  
	$config['charset'] = 'utf-8';  
	$config['wordwrap'] = TRUE;
?>