<div class="footer">
<div class="mw_left_ft">
	<ul>
			<li><?php echo anchor(base_url(),'Home')?></li>
			<li><?php echo anchor('barang/carabeli','Cara Pembelian')?></li>
			<li><?php echo anchor('biaya_kirim','Daftar biaya transport')?></li>
			<li><?php echo anchor('perusahaan/about_us','Tentang kami')?></li>
			<li><?php echo anchor(base_url().'admin','login')?></li>
	</ul>
</div>
<div class="mw_right_ft">
	<p>
		&copy; 2011 <a href=""><strong>eCommerce</strong></a>	
	</p>
</div>
<div class="clear_both"><span></span></div>		
</div>