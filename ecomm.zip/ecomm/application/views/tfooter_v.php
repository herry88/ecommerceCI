Powered by AtqoSoft <small><i>10 April </i></small>2011
<?php echo anchor(base_url(), 'Home')?>
<?php echo anchor(base_url().'asset/upload/KatalogBatik.doc', 'Daftar Harga')?>
<?php echo anchor('contact', 'Contact Us')?>