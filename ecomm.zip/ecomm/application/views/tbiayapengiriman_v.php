<div class='oval'><p><font color='red'><b>Jika tidak ingin melakukan pengiriman menggunakan jasa yang terdaftar dibawah ini, Cara pengiriman dapat disesuaikan dengan 
keinginan pembeli/pemesan. misalkan pengiriman melalui kereta api atau bus.</b></font></p>
<p>Harga dibawah ini adalah harga untuk 1 KG, biaya kirim tergantung berat barang yang dibeli.</p>
<table cellspacing="0" cellpadding="0" class="data-table">
<tr>
 <th>Reguler</th>
 <th>Kilat</th>
 <th>Penyedia</th>

</tr>
   <tr>
	<td>Aceh - Rp 35.000 - 3 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Ambon - Rp 53.000 - 5 hari</td>

	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Balikpapan - Rp 38.000 - 2 hari</td>
	<td>Balikpapan - Rp.66.600 - 1 hari</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>Bandarlampung - Rp 26.500  - 2 hari</td>
	<td>Bandarlampung - Rp. 43.000 - 1 hari</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>

	<td>Bandung - Rp 17.000 - 2 hari</td>
	<td>Bandung - Rp. 34.500 - 1 hari</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Banjarmasin - Rp 30.000 - 2 hari</td>
	<td>Banjarmasin - Rp. 50.000 - 1 hari</td>

	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Banyuwangi - Rp 40.000 - 3 hari</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>

     <tr>
	<td>Batam - Rp 30.000 - 2 hari</td>
	<td>Batam - Rp 56.000 - 1 hari</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Batang - Rp 33.000 - 3 hari</td>

	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Bekasi - Rp 20.000 - 2 hari</td>
	<td>Bekasi - Rp. 45.000 - 1 hari</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>Bengkulu - Rp 26.500 - 2 hari</td>
	<td>Bengkulu - Rp. 53.000 - 1 hari</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>

	<td>Biak - Rp. 114.000 - 14 hari</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Bima - Rp 43.000 - 3 hari</td>
	<td>TIDAK ADA</td>

	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Blitar - Rp 42.000 -43hari</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>

     <tr>
	<td>Blora - Rp.37000 - 3 hari</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Bogor - Rp 21.000 -  2 hari</td>

	<td>Tidak Ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Boyolali - Rp 29.000 - 2 hari</td>
	<td>Boyolali - Rp. 31.000 - 1 hari</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>Brebes Rp 36.400 - 3 hari</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>

	<td>Bukittinggi - Rp 36.400 - 4 hari</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Cengkaleng-Rp.15.000-2hr</td>
	<td></td>

	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Cianjur-Rp.30.000 - 3hr</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>

     <tr>
	<td>cilacap-Rp.21.000-3hr</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>cirebon-Rp.18.000-3hr</td>

	<td>cirebon-Rp. 34.000</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>demak-Rp.30.000-3hr</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>denpasar-Rp.21.000-2hr</td>
	<td>denpasar-Rp.48.000-1hr</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>

	<td>depok-Rp.20.000-2hr</td>
	<td>depok-Rp. 27.000-1hr</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>garut-Rp.22.000-3hr</td>
	<td>garut-Rp. 40.000-1hr</td>

	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>gorontalo-Rp.55.000-6hr</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>

     <tr>
	<td>gresik+Rp.31.000-3hr</td>
	<td>gresik-rp.45.000-1hr</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>jakarta-Rp.15.000-2hr</td>

	<td>jakarta-rp.24.000-1hr</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>jambi-Rp.27.000-2hr</td>
	<td>jambi-Rp.44.000-1hari</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>jember-Rp.29.000-3h</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>

	<td>jepara-Rp.29.000-3hr</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>jombang-Rp.32.500-3hr</td>
	<td>TIDAK ADA</td>

	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>karanganyar-Rp30.000-3hr</td>
	<td>karanganyar-Rp.31.000-1hr</td>
	<td>Tiki/JNE</td>
   </tr>

     <tr>
	<td>karawang-Rp.20.000-3hr</td>
	<td>karawang-Rp49.000-1hari</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>kebumen-Rp.29.000-3hr</td>

	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>kediri-Rp.28.000-3hr</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>kendal-Rp.24.000-3hr</td>
	<td>kendal-Rp.35.000-1hr</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>

	<td>kendari-Rp45.000-4hr</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>ketapang-Rp.59.000-4hr</td>
	<td>TIDAK ADA</td>

	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>klaten-Rp.18.000-3hr</td>
	<td>klaten-Rp.31.000-1hr</td>
	<td>Tiki/JNE</td>
   </tr>

     <tr>
	<td>kolaka-Rp.70.000-5hr</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>kotabaru-Rp.55.000-3hr</td>

	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>kudus-Rp.25.000-3hr</td>
	<td>kudus-Rp.35.000-1hr</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>kupang-Rp.38.000-3hr</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>

	<td>kuta-Rp.28.000-2hr</td>
	<td>kuta-Rp.51.000-1hr</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>kutai barat-Rp.77.000-7hr</td>
	<td>TIDAK ADA</td>

	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>kutai timurRp.69.000-7hr</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>

     <tr>
	<td>lahat-Rp.42.000-3hr</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>lamongan-Rp.32.000-3hr</td>

	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>lhoksumawe-Rp.61.000-4hr</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>lubuklinggau-Rp.42.000-3hr</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>

	<td>lumajang-Rp.30.000-3hr</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Luwuk Rp 61.000 -4 hari</td>
	<td>TIDAK ADA</td>

	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>madiun-Rp.26.000-3hr</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>

     <tr>
	<td>Magelang - Rp 12.000 -2 hari</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Magetan - Rp 29.000 -3 hari</td>

	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Majalengka-Rp 23.000-3hari</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>Majenang Rp 32.000 -4 hari</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>

	<td>Makassar Rp 39.000 - 2 hari</td>
	<td>Makassar Rp 72.000 - 1 hari</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Malang - Rp 23.000 -2 hari</td>
	<td>Malang - Rp 44.000 - 1hari</td>

	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Manado Rp 45.000 - 3 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>

     <tr>
	<td>Manggarai Rp 87.000 - 14hari</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Manokwari Rp 138.000 - 14 hari</td>

	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Martapura Rp 39.000 - 3 hari</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>Mataram Rp 16.000 -2 hari</td>
	<td>Mataram Rp. 49.000 - 1 hari</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>

	<td>Medan Rp 28.000 -2 hari</td>
	<td>Medan Rp. 61.000 - 1 hari</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Merauke Rp 116.000 - 14 hari</td>
	<td>TIDAK ADA</td>

	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Metro Rp35.000 -3 hari</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>

     <tr>
	<td>Minahasa Rp 90. 000 - Rp 15 hari</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Mojokerto Rp 27.000 - 2hari</td>

	<td>Mojokerto Rp 44.000 - 1 hari</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Muntilan Rp 10.000 - 2 hari</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>Negara Rp37.000 - 3hari</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>

	<td>Nganjuk Rp 15.000 - 3 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Ngawi Rp 29.000 - 3 hari</td>
	<td>TIDAK ADA</td>

	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Pacitan Rp 44.000 - 3hari</td>
	<td>TIDAK ADA</td>
	<td>Tiki/JNE</td>
   </tr>

     <tr>
	<td>Padang Pariaman Rp 37.000 - 4 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Padang Rp 26.000 - 2 hari</td>

	<td>Padang Rp 56.000 - 1 hari</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Palangkaraya Rp 30.000 - 2 hari</td>
	<td>Palangkaraya Rp 36.000 - 1 hari</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>Palembang Rp 16.000 - 3hari</td>
	<td>Palembang Rp 44.000 - 1 hari</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>

	<td>Palu Rp 54.000 - 3 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Pamekasan Rp 42.000 - 4 hari</td>
	<td>TIDAK ADA</td>

	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Pare-pare Rp 55.000 - 4 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>

     <tr>
	<td>Pasuruhan Rp 30.000 - 2 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Pati Rp 30.000 - 3 hari</td>

	<td>Tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Payakumbuh Rp 36.000 - 4 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>Pekalongan Rp 15.000 - 3 hari</td>
	<td></td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Pematang Siantar Rp 30.000 - 5 hari</td>

	<td></td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>Ponorogo Rp 31.000 - 3hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>Pontianak Rp 29.000 - 2 hari</td>
	<td>Pontianak Rp. 48.000 - 1 hari</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>

	<td>prabumulih - Rp.34.000 - 3hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>probolingg Rp.28.000 - 2hari</td>
	<td>tidak ada</td>

	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>pubalingga-Rp.31.000 - 3hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>

     <tr>
	<td>purwakarta Rp.30.000-3 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>purwokerto Rp.30.000-3 hari</td>

	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>purworejo Rp.15.000 - 3 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>puwadadi Rp.31.000 - 3 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>

	<td>rembang Rp.31.000- 3 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>salatiga Rp. 26.000 - 3 hari</td>
	<td>salatiga Rp. 35.000 - 1 hari</td>

	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>samarinda Rp. 37.000 - 2 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>

     <tr>
	<td>sambas Rp. 58.000 - 3 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>sampang Rp. 42.000- 3 hari</td>

	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>sampit Rp. 55.000 - 4 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>sanur Rp. 28.000- 2 hari</td>
	<td>sanur Rp. 51.000 - 1 hari</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>

	<td>sawahlunto Rp. 37.000 - 4 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>secang Rp. 12.000 - 2 hari</td>
	<td>tidak ada</td>

	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>semarang Rp. 16.000- 2 hari</td>
	<td>semarang Rp. 26.000 - 1 hari</td>
	<td>Tiki/JNE</td>
   </tr>

     <tr>
	<td>sibolga Rp. 49.000 -  4 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>sidoarjo Rp. 24.000 - 2 hari</td>

	<td>sidoarjo Rp.45.000 - 1 hari</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>singkawang Rp. 45.000 - 3 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>situbondo Rp. 38.000 - 3 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>

	<td>sleman Rp. 0 - kami antar</td>
	<td>sleman Rp. 0 - kami antar</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>solo Rp. 15.000 - 2 hari</td>
	<td>solo Rp. 26.000 - 1 hari</td>

	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>solok Rp. 36.400 - 5 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>

     <tr>
	<td>sragen Rp. 29.000 - 3 hari</td>
	<td>sragen Rp. 31.000 - 1 hari</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>subang Rp. 23.000 - 3 hari</td>

	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>sukabumi Rp. 27.000 - 3 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>sukoharjo Rp. 30.000- 3 hari</td>
	<td>sukoharjo Rp. 31.000 - 1 hari</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>

	<td>sumbawa besar Rp. 46.000 - 3 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>sumedang Rp. 25.000 - 3 hari</td>
	<td>sumedang Rp. 40.800 - 1 hari</td>

	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>sumenep Rp. 42.000 - 4 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>

     <tr>
	<td>surabaya Rp. 22.000 - 2 hari</td>
	<td>surabaya Rp. 37.200 - 1 hari</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>tangerang Rp. 19.000 - 2 hari</td>

	<td>tangerang Rp 31.500 - 1 hari</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>tanjung enim Rp. 41.600 -  3hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>tarakan Rp. 49.000 - 2 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>

	<td>tasikmalaya Rp. 27.000 - 3 hari</td>
	<td>tasikmalaya Rp. 40.800 - 1 hari</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>tegal Rp. 31.000 - 3 hari</td>
	<td>tidak ada</td>

	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>temanggung Rp. 22.000  - 3 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>

     <tr>
	<td>tenggarong Rp. 53.000 - 3 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>ternate Rp. 56.000 - 5 hari</td>

	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>timika Rp. 115.000 - 14 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>toli - toli Rp. 63.000- 5 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>

	<td>toraja Rp. 75.600 - 10 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>tuban Rp. 32.000 - 3 hari</td>
	<td>tidak ada</td>

	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>tulung agung Rp. 36.400 - 3 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>

     <tr>
	<td>ungaran Rp. 24.000 - 2 hari</td>
	<td>ungaran Rp. 34.000 - 1 hari</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>wameina Rp. 137.800 - 14 hari</td>

	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>
	<td>wates Rp. 11.700 - 3 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>

   </tr>
     <tr>
	<td>wonosari Rp. 11.700 - 3 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
     <tr>

	<td>wonosobo Rp. 22.000 - 3 hari</td>
	<td>tidak ada</td>
	<td>Tiki/JNE</td>
   </tr>
  </table>
  </div>