<?php
	echo "Selamat datang di administrator";
?>