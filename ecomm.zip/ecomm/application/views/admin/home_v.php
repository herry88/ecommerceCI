<style>
	legend{border:1px solid silver;padding:5px;}
	fieldset{border:1px solid silver;padding:10px;margin:10px;}
	.list-petunjuk ol{
		line-height:20px;
	}
</style>
<div id="panel">
	<?php echo anchor(base_url().'admin','Administrator');?>
</div><div id="clear"></div>
<?php
	echo "Selamat Datang Administrator eCommerce";
?>
<fieldset>
<legend>Petunjuk Penggunaan Admin Web</legend>
<ul class='list-petunjuk'>
	<ol>1. Gunakan dengan bijak, fasilitas-fasilitas yang telah disediakan</ol>
	<ol>2. Harap me-LogOut terlebih dahulu ketika meninggalkan sistem</ol>
</ul>
</fieldset>