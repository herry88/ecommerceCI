<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<script type='text/javascript'>
    $(function() {
		load('<?=$url?>','<?=$div?>');
    });
</script>